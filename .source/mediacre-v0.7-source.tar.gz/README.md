# MEDIA CRE Website

BTL Representative Company · Outdoor Media Creative Power

This repository contains the pre-deployment production candidate for the MEDIA CRE corporate website. Company facts are grounded in the supplied 2024 company profile. Prototype visuals and benchmark-derived experience patterns are explicitly separated from verified company information.

## Stack
- Next.js 16 App Router
- React 19
- TypeScript
- Native responsive CSS
- Vercel deployment target

## Local development
```bash
npm install
cp .env.example .env.local
npm run dev
```

## Verification
```bash
npm run validate
npm run build
```

`validate` runs content-integrity checks, environment checks, contact validation tests, TypeScript, and ESLint.

## Environment
- `NEXT_PUBLIC_SITE_URL`: canonical site URL
- `CONTACT_MODE`: `mock` or `webhook`
- `CONTACT_WEBHOOK_URL`: required only in webhook mode
- `CONTACT_WEBHOOK_BEARER_TOKEN`: optional outbound bearer token
- `CONTACT_ALLOWED_ORIGINS`: optional comma-separated origin allow-list

The contact endpoint defaults to mock mode and does not persist or transmit submitted content.

## Routes
- `/`
- `/work`
- `/work/[slug]`
- `/services`
- `/about`
- `/contact`
- `/privacy` (prototype/noindex)
- `/brand-preview` (noindex)
- `/api/health`
- `/api/contact`

## Deployment state
`predeploy/v0.7` is the review branch. Do not merge to `main` until GitHub Actions passes and the deployment checklist is reviewed. Vercel connection is intentionally left for the final deployment step.

## Source policy
- Verified company facts: supplied MEDIA CRE company profile (2024)
- Prototype: logo route, hero art, portfolio visual placeholders, workflow descriptions, form delivery layer
- Never invent legal/contact facts or present generated assets as real campaign evidence
