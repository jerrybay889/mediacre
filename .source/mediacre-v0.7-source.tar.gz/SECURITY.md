# Security Policy

Do not open a public issue for a vulnerability that could expose user-submitted contact information. Contact the repository owner privately through GitHub.

The contact endpoint defaults to `mock` mode. Production webhook delivery must be enabled explicitly with environment variables. Secrets must never be committed.
