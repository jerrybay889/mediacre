# MEDIA CRE Full QA Report · v0.6

## Executive result

**Status: COMPLETE WITH ONE ENVIRONMENT-LIMITED BUILD CHECK**

- Vercel: intentionally not connected
- Company-profile integrity: PASS
- Static source and asset validation: **529/529 PASS**
- Desktop/mobile browser validation: **324/324 PASS**
- Local HTTP smoke tests: **17/17 PASS**
- Contact validation unit tests: PASS
- Offline TypeScript/JSX validation: PASS
- Real Next.js dependency install and `next build`: BLOCKED by the current internal package registry

## 1. Source integrity

### Passed

- Public company name normalized to `MEDIA CRE` / `미디어크리`.
- `BTL Representative Company`, Outdoor Media Creative Power, Outdoor Annual Plan, Customized Media, Promotion, Viral Marketing and IMC were derived from the supplied company profile.
- `재미와의미` (2018, `www.sellcommerce.kr`) and `한차이나` (2015, `www.hanch.co.kr`) are reproduced as profile-stated information.
- Six portfolio records were corrected and given explicit profile page references.
- The profile's `현재` wording is treated as a 2024-document statement rather than a 2026 active-contract claim.
- Representative, address, official email and telephone were not invented.

See `SOURCE_PROVENANCE_v0.6.md`.

## 2. Benchmark-based prototype boundary

The following are intentionally virtual and were tested as design/UX production assets:

- Urban Frame provisional identity
- Cinematic urban hero
- Generated case placeholders
- Six-stage delivery model
- Project brief workflow
- Analytics-event scaffolding
- Privacy and inquiry prototypes

All generated or inferred elements are separated from campaign evidence through labels and documentation.

## 3. Automated validation matrix

| Validation | Result | Evidence |
|---|---:|---|
| Content and source-gap validation | PASS | `scripts/check-content.mjs` |
| Contact payload unit tests | PASS | `scripts/test-contact.mjs` |
| Offline TypeScript/JSX validation | PASS | `tsc --noEmit` with offline declarations |
| Static pages, links, labels and assets | 529/529 PASS | `STATIC_VALIDATION_RESULTS_v0.6.json` |
| Chromium desktop/mobile rendering | 324/324 PASS | `BROWSER_QA_RESULTS_v0.6.json` |
| Local HTTP responses | 17/17 PASS | `HTTP_SMOKE_RESULTS_v0.6.json` |
| Hero desktop WebP | PASS | 1792×1024 · 71,466 bytes |
| Hero mobile WebP | PASS | 1024×1792 · 102,550 bytes |
| Desktop/mobile screenshots | PASS | 24 full-page screenshots |

## 4. Browser and interaction coverage

Validated at:

- Desktop: 1440×1000
- Mobile: 390×844

Covered:

- 12 standalone pages in both viewports
- Page title, one H1, main/nav/footer landmarks
- Alt attributes and named buttons
- Internal links and referenced assets
- Horizontal-overflow detection
- Mobile navigation open state
- Work-category filtering and result count
- Contact required-field error state
- Contact mock success state
- First-tab skip-link focus
- WCAG AA contrast for core token combinations
- Full-page screenshots and console/page-error capture

No browser-console or page errors were recorded in the inlined validation environment.

## 5. Local HTTP smoke test

A local static server returned HTTP 200 for:

- 12 HTML pages
- CSS and JavaScript
- Desktop and mobile hero assets

A missing path returned HTTP 404 as expected.

Chromium's direct navigation to localhost was blocked by the execution platform administrator. Therefore browser rendering used equivalent fully inlined HTML/CSS/JS/assets, while HTTP response behavior was checked separately with a local server client.

## 6. Security and privacy checks

Implemented and inspected:

- Required privacy consent
- Honeypot field
- Email format validation
- Maximum 5,000-character message length
- JSON content-type enforcement
- Mock mode that does not store or externally forward submissions
- Health endpoint indicating mock/webhook mode
- `X-Content-Type-Options`, `X-Frame-Options`, Referrer Policy and Permissions Policy configuration
- Prototype privacy notice with explicit source gaps

The policy page remains a prototype and is not a legally approved privacy policy.

## 7. Framework build limitation

The real command below was attempted:

```bash
npm install --ignore-scripts --no-audit --no-fund
```

The configured internal npm registry returned HTTP 404 for required packages such as `@types/node`; Next.js, React and related packages are not installed in this environment. Consequently, a real `next build` could not be executed here.

Mitigation completed:

- Offline TypeScript/JSX syntax and project-owned types passed.
- Static production-equivalent pages passed 324 browser checks.
- All internal links, assets, forms and responsive states were independently validated.
- The final package contains exact commands for the target GitHub/Vercel package environment.

This is the only non-Vercel verification item that remains dependent on an external package environment.

## 8. Release gate

### Completed before Vercel

- Source-derived company information
- Benchmark-based responsive production design
- Desktop/mobile QA
- Interaction QA
- Accessibility baseline
- Contact mock security and validation
- Static SEO structure
- JSON-LD structure
- Sitemap/robots source
- QA evidence package

### Intentionally deferred

- Vercel account and deployment
- Domain connection
- Real inquiry destination and data retention
- Production analytics IDs
- Legal approval of the privacy policy
- Replacement of all generated portfolio visuals with rights-cleared original campaign files
